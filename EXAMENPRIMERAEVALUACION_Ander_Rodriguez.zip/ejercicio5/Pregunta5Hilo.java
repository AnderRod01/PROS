package ejercicio5;

public class Pregunta5Hilo extends Thread{
	
	
	public Pregunta5Hilo (String nombre) {
		this.setName(nombre);
	}
	
	@Override
	public void run() {
		for (int cont =1; cont<=3; cont++) {
			System.out.println(this.getName() + cont);
		}
	}
}
