package actividad3;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Actividad3 {
	public static void main(String[] args) {

		InetAddress [] address;
		
		try {
			//comprobamos que se haya pasado una direccion por parametro
			if (args.length != 0) {
				//guardamos en un array todas las direcciones IP
				address  = InetAddress.getAllByName(args[0]);
				//Escribimos por pantalla su informacion
				System.out.println("Dirección IP: " + InetAddress.getByName(args[0]));
				System.out.println("Nombre: " + args [0]);
				for (int i=0; i<address.length;i++) {
					System.out.println(address[i]);
				}
			}
			else {
				System.out.println("Se necesita una URL para obtener su dirección");
				
			}
		} catch (UnknownHostException e) {
			
			//Si la direccion no es correcta, usamos las direcciones IP locales
			try {
				//Cogemos la direccion local
				InetAddress local = InetAddress.getLocalHost();
				
				//guardamos en un array todas las direcciones IP
				address  = InetAddress.getAllByName(local.getHostName());
				
				//Escribimos por pantalla su informacion
				System.out.println("Dirección IP: " + local.getHostAddress());
				System.out.println("Nombre: " + local.getHostName());
				for (int i=0; i<address.length;i++) {
					System.out.println(address[i]);
				}
				
				
			} catch (UnknownHostException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			
		}
		
	}
}
