package actividad1;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Actividad1 {
	
	public static void main(String[] args) {
		InetAddress[] address;
		
		try {
			//guardamos en un array todas las direcciones IP
			address = InetAddress.getAllByName("www.spotify.com");
			//Bucle para escribirlo por pantalla
			for (int i=0; i<address.length;i++) {
				System.out.println(address[i]);
			}
		} catch (UnknownHostException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
