package actividad2;

import java.net.InetAddress;
import java.net.UnknownHostException;

public class Actividad2 {
	public static void main(String[] args) {
		InetAddress [] address;
		
		try {
			//comprobamos que se haya pasado una direccion por parametro
			if (args.length != 0) {
				//guardamos en un array todas las direcciones IP
				address  = InetAddress.getAllByName(args[0]);
				//Bucle para escribirlo por pantalla
				for (int i=0; i<address.length;i++) {
					System.out.println(address[i]);
				}
			}else {
				//Si no se ha pasado nada, escribimos un mensaje por pantalla
				System.out.println("Se necesita una URL para obtener su dirección");
			}
		
		} catch (UnknownHostException e) {}
	}
}
