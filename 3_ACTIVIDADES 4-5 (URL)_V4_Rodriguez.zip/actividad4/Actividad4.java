package actividad4;

import java.net.MalformedURLException;
import java.net.URL;

public class Actividad4 {
	
	
	//Metodo para visualizar informacion de la url
	private static void visualizar (URL url) {
		System.out.println("\tMetodo toString(): " +url.toString() +
		"\n\tMetodo getProtocol(): " + url.getProtocol() +
		"\n\tMetodo getHost(): "  + url.getHost() +
		"\n\tMetodo getPort(): " + url.getPort() +
		"\n\tMetodo getFile(): " + url.getFile() +
		"\n\tMetodo getUserInfo(): " + url.getUserInfo() +
		"\n\tMetodo getPath(): " + url.getPath() +
		"\n\tMetodo getAuthority(): " + url.getAuthority() +
		"\n\tMetodo getQuery(): " + url.getAuthority());

		
	}
	
	public static void main(String[] args) {
		try {
			
			//Constructores de URL
			URL url1 = new URL("http://docs.oracle.com");
			URL url2 = new URL("http", "docs.oracle.com", "/javase/7/docs/api/java/net/URL.html");
			URL url3 = new URL("http", "docs.oracle.com", 7,"/javase/7/docs/api/java/net/URL.html");
			URL url4 = new URL(url1,"/javase/7/docs/api/java/net/URL.html" );
			
			
			//Visualizar informacion
			System.out.println("Constructor simple para una URL:");
			visualizar(url1);
			
			System.out.println("Constructor para protocolo, host y directorio:");
			visualizar(url2);
			
			System.out.println("Constructor para protocolo, host, puerto y directorio:");
			visualizar(url3);
			
			System.out.println("Constructor para un objeto URL y us directorio:");
			visualizar(url4);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	
}
